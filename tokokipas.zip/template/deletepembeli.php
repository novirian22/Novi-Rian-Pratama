<?php
$idpembeli = $_GET['id_pembeli'];

$conn = mysqli_connect("localhost","root","","tokokipas");
$result = mysqli_query($conn,"DELETE FROM pembeli WHERE id_pembeli=$idpembeli");

echo "<script>
		alert('data berhasil dihapus');
		document.location.href ='index.php?halaman=showpembeli';
		</script>
";

?>