<?php


require 'function.php';

$conn = mysqli_connect("localhost", "root", "", "tokokipas");


if(isset($_POST["submit"]) ){
    
    $id_pembeli                 = $_POST['id_pembeli'];
    $nama_pembeli               = htmlspecialchars($_POST['nama_pembeli']);
    $no_telp                     = htmlspecialchars($_POST['no_telp']);
    $alamat                      = htmlspecialchars($_POST['alamat']);

        
        // include database connection file
    include_once("function.php");

        // Insert user data into table
    $result = mysqli_query($conn, "INSERT INTO pembeli(id_pembeli,nama_pembeli,no_telp,alamat) VALUES('$id_pembeli','$nama_pembeli','$no_telp','$alamat')");

        // Show message when user added
    echo "
    <script>
    alert('Data berhasil ditambahkan !!!!!')
    document.location.href = 'index.php?halaman=showpembeli';
    </script>
    ";

}





?>


<form action="" method="post">
  <div class="form-group">
    <label for="id_pembeli">id_pembeli</label>
    <input type="text" class="form-control" name="id_pembeli" id="id_pembeli" >  
  </div>

  <div class="form-group">
    <label for="nama_pembeli">nama_pembeli</label>
    <input type="text" class="form-control" name="nama_pembeli" id="nama_pembeli"  maxlength="20" autocomplete="off">
  </div>

<div class="form-group">
    <label for="no_telp">no_telp</label>
    <input type="text" class="form-control" name="no_telp" id="no_telp" placeholder="masukkan no_telp" autocomplete="off" maxlength="20">
</div>

  <div class="form-group">
    <label for="alamat">alamat</label>
    <input type="text" class="form-control" name="alamat" id="alamat" placeholder="masukkan alamat" autocomplete="off" maxlength="100">
  </div>

  
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>