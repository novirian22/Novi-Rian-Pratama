<?php
require 'function.php';
$conn = mysqli_connect("localhost", "root", "", "tokokipas");

//ambil data id transaksi
$id_transaksi = $_GET["id_transaksi"];

//query data berdasarkan id_transaksi
$id_transaksi = query("SELECT * FROM transaksi WHERE id_transaksi = $id_transaksi")[0];


if(isset($_POST["submit"]) ){
    
    $id_transaksi = $_POST['id_transaksi'];
     $id_barang               = htmlspecialchars($_POST['id_barang']);
    $id_pembeli                     = htmlspecialchars($_POST['id_pembeli']);
    $tanggal                      = htmlspecialchars($_POST['tanggal']);
    $keterangan               = htmlspecialchars($_POST['keterangan']);


    // update transaksi data
    $result = mysqli_query($conn, "UPDATE transaksi SET id_barang='$id_barang',id_pembeli='$id_pembeli',tanggal='$tanggal' ,keterangan='$keterangan' WHERE id_transaksi=$id_transaksi");

    // Redirect to homepage to display updated transaksi in list
    // header("Location: index.php");
    
    echo "
 				<script>
 				alert('data berhasil diubah');
 				document.location.href = 'index.php?halaman=showtransaksi';
 				</script>
 		";


}
?>
<form action="" method="post">
  <div class="form-group">
    <label for="id_transaksi">ID transaksi</label>
    <input type="text" class="form-control" name="id_transaksi" id="id_transaksi" value="<?= $id_transaksi["id_transaksi"];?>" readonly>  
  </div>

  <div class="form-group">
    <label for="id_barang">id_barang</label>
    <select name="id_barang" class="form-control" id="id_barang">

        <?php
          $conn = mysqli_connect("localhost", "root", "", "tokokipas");
          $result = mysqli_query($conn, "SELECT * FROM barang ORDER BY id_barang");
          while ($row = mysqli_fetch_assoc($result)) 
          {
            echo "<option>$row[id_barang] $row[nama_barang]</option>";
          }
        ?>
    </select>
  </div>

<div class="form-group">
    <label for="id_pembeli">id_pembeli</label>
     <select name="id_pembeli" class="form-control" id="id_pembeli">

        <?php
          $conn = mysqli_connect("localhost", "root", "", "tokokipas");
          $result = mysqli_query($conn, "SELECT * FROM pembeli ORDER BY id_pembeli");
          while ($row = mysqli_fetch_assoc($result)) 
          {
            echo "<option>$row[id_pembeli] $row[nama_pembeli]</option>";
          }
        ?>
    </select>
</div>
 <div class="form-group">
    <label for="tanggal">tanggal</label>
    <input type="date" class="form-control" name="tanggal" id="tanggal" value="<?= $id_transaksi["tanggal"];?>" >  
  </div>
  <div class="form-group">
    <label for="keterangan">keterangan</label>
    <input type="text" class="form-control" name="keterangan" id="keterangan" placeholder="masukkan keterangan " autocomplete="off" maxlength="20" value="<?= $id_transaksi["keterangan"];?>">
  </div>

 
  
<!--  -->
   
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>