<?php
require 'function.php';
$conn = mysqli_connect("localhost", "root", "", "tokokipas");

//ambil data id pembeli
$id_pembeli = $_GET["id_pembeli"];

//query data berdasarkan id_pembeli
$id_pembeli = query("SELECT * FROM pembeli WHERE id_pembeli = $id_pembeli")[0];


if(isset($_POST["submit"]) ){
    
    $id_pembeli = $_POST['id_pembeli'];
    $nama_pembeli = htmlspecialchars($_POST['nama_pembeli']);
    $no_telp = htmlspecialchars($_POST['no_telp']);
    $alamat = htmlspecialchars($_POST['alamat']);


    // update supplier data
    $result = mysqli_query($conn, "UPDATE pembeli SET nama_pembeli='$nama_pembeli',no_telp='$no_telp',alamat='$alamat'  WHERE id_pembeli=$id_pembeli");

    // Redirect to homepage to display updated supplier in list
    // header("Location: index.php");
    
    echo "
 				<script>
 				alert('data berhasil diubah');
 				document.location.href = 'index.php?halaman=showpembeli';
 				</script>
 		";


}
?>
<form action="" method="post">
  <div class="form-group">
    <label for="id_pembeli">ID pembeli</label>
    <input type="text" class="form-control" name="id_pembeli" id="id_pembeli" value="<?= $id_pembeli["id_pembeli"];?>" readonly>  
  </div>

  <div class="form-group">
    <label for="nama_pembeli">Nama pembeli</label>
    <input type="text" class="form-control" name="nama_pembeli" id="nama_pembeli" autofocus="" maxlength="10" autocomplete="off" value="<?= $id_pembeli["nama_pembeli"];?>">
  </div>

<div class="form-group">
    <label for="no_telp">no_telp</label>
    <input type="text" class="form-control" name="no_telp" id="no_telp" placeholder="masukkan no_telp " autocomplete="off" maxlength="100" value="<?= $id_pembeli["no_telp"];?>">
</div>

  <div class="form-group">
    <label for="alamat">alamat</label>
    <input type="text" class="form-control" name="alamat" id="alamat" placeholder="masukkan alamat " autocomplete="off" maxlength="20" value="<?= $id_pembeli["alamat"];?>">
  </div>

 
  
<!--  -->
   
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>