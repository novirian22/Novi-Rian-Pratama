<?php


require 'function.php';

$conn = mysqli_connect("localhost", "root", "", "tokokipas");


if(isset($_POST["submit"]) ){
    
    $id_supplier                 = $_POST['id_supplier'];
    $nama_supplier               = htmlspecialchars($_POST['nama_supplier']);
    $no_telp                     = htmlspecialchars($_POST['no_telp']);
    $alamat                      = htmlspecialchars($_POST['alamat']);

        
        // include database connection file
    include_once("function.php");

        // Insert user data into table
    $result = mysqli_query($conn, "INSERT INTO supplier(id_supplier,nama_supplier,no_telp,alamat) VALUES('$id_supplier','$nama_supplier','$no_telp','$alamat')");

        // Show message when user added
    echo "
    <script>
    alert('Data berhasil ditambahkan !!!!!')
    document.location.href = 'index.php?halaman=showsupplier';
    </script>
    ";

}





?>


<form action="" method="post">
  <div class="form-group">
    <label for="id_supplier">id_supplier</label>
    <input type="text" class="form-control" name="id_supplier" id="id_supplier" >  
  </div>

  <div class="form-group">
    <label for="nama_supplier">nama_supplier</label>
    <input type="text" class="form-control" name="nama_supplier" id="nama_supplier"  maxlength="20" autocomplete="off">
  </div>

<div class="form-group">
    <label for="no_telp">no_telp</label>
    <input type="text" class="form-control" name="no_telp" id="no_telp" placeholder="masukkan no_telp" autocomplete="off" maxlength="20">
</div>

  <div class="form-group">
    <label for="alamat">alamat</label>
    <input type="text" class="form-control" name="alamat" id="alamat" placeholder="masukkan alamat" autocomplete="off" maxlength="100">
  </div>

  
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>