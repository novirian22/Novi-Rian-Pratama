<?php


require 'function.php';

$conn = mysqli_connect("localhost", "root", "", "tokokipas");


if(isset($_POST["submit"]) ){
    
    $id_barang                 = $_POST['id_barang'];
    $nama_barang               = htmlspecialchars($_POST['nama_barang']);
    $harga                     = htmlspecialchars($_POST['harga']);
    $stok                      = htmlspecialchars($_POST['stok']);
    $id_supplier               = htmlspecialchars($_POST['id_supplier']);

        
        // include database connection file
    include_once("function.php");

        // Insert user data into table
    $result = mysqli_query($conn, "INSERT INTO barang(id_barang,nama_barang,harga,stok,id_supplier) VALUES('$id_barang','$nama_barang','$harga','$stok','$id_supplier')");

        // Show message when user added
    echo "
    <script>
    alert('Data berhasil ditambahkan !!!!!')
    document.location.href = 'index.php?halaman=showbarang';
    </script>
    ";

}





?>


<form action="" method="post">
  <div class="form-group">
    <label for="id_barang">id_barang</label>
    <input type="text" class="form-control" name="id_barang" id="id_barang" >  
  </div>

  <div class="form-group">
    <label for="nama_barang">nama_barang</label>
    <input type="text" class="form-control" name="nama_barang" id="nama_barang"  maxlength="20" autocomplete="off">
  </div>

<div class="form-group">
    <label for="harga">harga</label>
    <input type="text" class="form-control" name="harga" id="harga" placeholder="masukkan harga" autocomplete="off" maxlength="20">
</div>

  <div class="form-group">
    <label for="stok">stok</label>
    <input type="text" class="form-control" name="stok" id="stok" placeholder="masukkan stok" autocomplete="off" maxlength="20">
  </div>

  <div class="form-group">
    <label for="id_supplier">id_supplier</label>
    <select name="id_supplier" class="form-control" id="id_supplier">

        <?php
          $conn = mysqli_connect("localhost", "root", "", "tokokipas");
          $result = mysqli_query($conn, "SELECT * FROM supplier ORDER BY id_supplier");
          while ($row = mysqli_fetch_assoc($result)) 
          {
            echo "<option>$row[id_supplier] $row[nama_supplier]</option>";
          }
        ?>
    </select>
  </div>
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>