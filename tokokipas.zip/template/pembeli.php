<?php

require 'function.php';

$idpembeli = query("SELECT * FROM pembeli ORDER BY id_pembeli ASC");
?>
<div class="panel panel-default">
  <div class="panel-heading">
   <h4 align="center">DATA PEMBELI </h4>
  </div>


 <div class="row">
   <div class="panel-body">

    <form action="" method="post">




      <a href="index.php?halaman=addpembeli" class="btn btn-outline-primary">Tambah pembeli</a>
      <a class="btn btn-outline-primary" href="index.php?halaman=showpembeli" role="button">Refresh</a>


    </form>
    <br>

    <div class="table-responsive">
      <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <thead>
          <tr>
            <th  class="align-middle text-center">No</th>
            <th class="align-middle text-center">Id pembeli</th>
            <th class="align-middle text-center">nama pembeli</th>
            <th class="align-middle text-center">no telepon pembeli</th>
            
            <th class="align-middle text-center">alamat</th>
            
            
            
           
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $i = 1; ?>
          <?php  foreach( $idpembeli as $row) : ?>
            <tr>
              <td><?php echo $i; ?></td>
              <td><?php echo $row['id_pembeli']; ?></td>
              <td><?php echo $row['nama_pembeli']; ?></td>
              <td><?php echo $row['no_telp']; ?></td>
              <td><?php echo $row['alamat']; ?></td>
            

              <td>

                <a href="index.php?halaman=updatepembeli&id_pembeli=<?= $row["id_pembeli"] ?>">update </a> | 
                
                <a href="index.php?halaman=deletepembeli&id_pembeli=<?= $row["id_pembeli"]; ?>" onclick="return confirm('Anda yakin ingin menghapus data ini ???');">delete </a>

              </td>


            </tr>
            <?php $i++; ?>
          <?php endforeach; ?>
        </tbody>
      </table>
      
    </div>
  </div>
</div>
</div>