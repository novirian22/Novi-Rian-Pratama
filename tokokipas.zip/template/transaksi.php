<?php

require 'function.php';

$idtransaksi = query("SELECT * FROM transaksi ORDER BY id_transaksi ASC");
?>
<div class="panel panel-default">
  <div class="panel-heading">
   <h4 align="center">DATA TRANSAKSI</h4>
  </div>


 <div class="row">
   <div class="panel-body">

    <form action="" method="post">




      <a href="index.php?halaman=addtransaksi" class="btn btn-outline-primary">Tambah transaksi</a>
      <a class="btn btn-outline-primary" href="index.php?halaman=showtransaksi" role="button">Refresh</a>


    </form>
    <br>

    <div class="table-responsive">
      <table class="table table-striped table-bordered table-hover" id="dataTables-example">
        <thead>
          <tr>
            <th  class="align-middle text-center">No</th>
            <th class="align-middle text-center">Id transaksi</th>
            <th class="align-middle text-center">Id Barang</th>
            <th class="align-middle text-center">Id Pembeli</th>
            <th class="align-middle text-center">Tanggal</th>
            
            <th class="align-middle text-center">Keterangan</th>
            
            
            
           
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $i = 1; ?>
          <?php  foreach( $idtransaksi as $row) : ?>
            <tr>
              <td><?php echo $i; ?></td>
              <td><?php echo $row['id_transaksi']; ?></td>
              <td><?php echo $row['id_barang']; ?></td>
              <td><?php echo $row['id_pembeli']; ?></td>
              <td><?php echo $row['tanggal']; ?></td>
                          <td><?php echo $row['keterangan']; ?></td>


              <td>

                <a href="index.php?halaman=updatetransaksi&id_transaksi=<?= $row["id_transaksi"] ?>">update </a> | 
                
                <a href="index.php?halaman=deletetransaksi&id_transaksi=<?= $row["id_transaksi"]; ?>" onclick="return confirm('Anda yakin ingin menghapus data ini ???');">delete </a>

              </td>


            </tr>
            <?php $i++; ?>
          <?php endforeach; ?>
        </tbody>
      </table>
      
    </div>
  </div>
</div>
</div>