<?php
$idtransaksi = $_GET['id_transaksi'];

$conn = mysqli_connect("localhost","root","","tokokipas");
$result = mysqli_query($conn,"DELETE FROM transaksi WHERE id_transaksi=$idtransaksi");

echo "<script>
		alert('data berhasil dihapus');
		document.location.href ='index.php?halaman=showtransaksi';
		</script>
";

?>