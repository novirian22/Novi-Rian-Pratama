<?php
require 'function.php';
$conn = mysqli_connect("localhost", "root", "", "tokokipas");

//ambil data id barang
$id_barang = $_GET["id_barang"];

//query data berdasarkan id_barang
$id_barang = query("SELECT * FROM barang WHERE id_barang = $id_barang")[0];


if(isset($_POST["submit"]) ){
    
    $id_barang = $_POST['id_barang'];
    $nama_barang = htmlspecialchars($_POST['nama_barang']);
    $harga = htmlspecialchars($_POST['harga']);
    $stok = htmlspecialchars($_POST['stok']);
        $idsup = htmlspecialchars($_POST['id_supplier']);


    // update supplier data
    $result = mysqli_query($conn, "UPDATE barang SET nama_barang='$nama_barang',harga='$harga',stok='$stok',id_supplier='$idsup'  WHERE id_barang=$id_barang");

    // Redirect to homepage to display updated supplier in list
    // header("Location: index.php");
    
    echo "
 				<script>
 				alert('data berhasil diubah');
 				document.location.href = 'index.php?halaman=showbarang';
 				</script>
 		";


}
?>
<form action="" method="post">
  <div class="form-group">
    <label for="id_barang">ID barang</label>
    <input type="text" class="form-control" name="id_barang" id="id_barang" value="<?= $id_barang["id_barang"];?>" readonly>  
  </div>

  <div class="form-group">
    <label for="nama_barang">Nama barang</label>
    <input type="text" class="form-control" name="nama_barang" id="nama_barang" autofocus="" maxlength="10" autocomplete="off" value="<?= $id_barang["nama_barang"];?>">
  </div>

<div class="form-group">
    <label for="harga">harga</label>
    <input type="text" class="form-control" name="harga" id="harga" placeholder="masukkan harga " autocomplete="off" maxlength="100" value="<?= $id_barang["harga"];?>">
</div>

  <div class="form-group">
    <label for="stok">stok</label>
    <input type="text" class="form-control" name="stok" id="stok" placeholder="masukkan stok " autocomplete="off" maxlength="20" value="<?= $id_barang["stok"];?>">
  </div>

 
  
<!--  -->
   <div class="form-group">
    <label for="id_supplier" class="col-sm-2 col-form-label">Kode supplier</label>
    <select name="id_supplier" class="form-control" id="id_supplier">
        <?php
$conn = mysqli_connect("localhost", "root", "", "tokokipas");

          $result = mysqli_query($conn, "SELECT * FROM supplier ORDER BY id_supplier");
          while ($row = mysqli_fetch_assoc($result)) 
          {
            echo "<option>$row[id_supplier] $row[nama]</option>";
          }
        ?>
    </select>
  </div>
  <br>
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>